Outline of the files here.

/GeantExample2Part1/ - Contains all Geant code used in this project. Currently running for visualisation rather than data collection, but can be swapped by adjusting the commented lines in run.mac and main.cpp, then building the code clean.

/image/ - Contains a lot of the images used in the jupyter notebook.

/xxxxBeam/ - csv data from one of the two types of data collection processes used in this project (Events separated by gun energy increases of 200 MeV, from 200 MeV -> 20 GeV). Separated by particle type.

/10000Events/ - csv data for the second type of data collection process (10000 Events at specific energies for each particle type. 200 MeV, 2000 MeV, 20 Gev)

confmatXXXXX - png images of our confusion matrices for each model. These are within the jupyter notebook and should only be looked at if you dont want to run the ML code

P3-WAITON-S1739002.ipynb - The full jupyter notebook, with all the outputs wiped (as requested). This will run flawlessly, although may take a while due to the machine learning components. Thats why I've also created...

P3-WAITON-S1739002-WITH-RESULTS.ipynb - The full jupyter notebook including all the outputs from the machine learning and work throughout the project. This is in case you want to skip waiting for the models to compile and check the validity of my work.

While in truth, I should just save the models and load them into the notebook. I feel that isn't any more or less 'trustworthy' than what I've done here, and hope you can forgive my shortcut to avoid doing this (it takes time and also requires you to code in "if the model is saved, load in rather than training again").
