#include "DetectorConstruction.h"
#include "EnergyCounter.h"
#include "PositionFinder.h"

#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4AutoDelete.hh"
#include "G4GeometryManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4SDManager.hh"

// Set number of detector layers
G4int const nLayers = 5;
G4int const nSLayers = 3;

G4ThreadLocal
G4GlobalMagFieldMessenger* DetectorConstruction::m_magneticFieldMessenger = 0;

DetectorConstruction::DetectorConstruction() : G4VUserDetectorConstruction()
{
}

DetectorConstruction::~DetectorConstruction()
{
}

// Here we define the actual experiment that we want to perform
G4VPhysicalVolume* DetectorConstruction::Construct()
{
  // Materials
  // http://geant4-userdoc.web.cern.ch/geant4-userdoc/UsersGuides/ForApplicationDeveloper/html/Appendix/materialNames.html
  G4NistManager* nistManager = G4NistManager::Instance();
  G4Material* vacuum = nistManager->FindOrBuildMaterial( "G4_Galactic" );
  G4Material* lead = nistManager->FindOrBuildMaterial( "G4_Pb" );
  G4Material* CsI = nistManager->FindOrBuildMaterial("G4_CESIUM_IODIDE");
  G4Material* liquidArgon = nistManager->FindOrBuildMaterial( "G4_lAr" );
  G4Material* silicon = nistManager->FindOrBuildMaterial( "G4_Si" );

  // Sizes of the principal geometrical components (solids)
  G4double absorberThickness = 0.5*cm;
  G4double absorberRadius = 50.0*cm;
  G4double detectorThickness = 10.0*cm;
  G4double detectorRadius = 50.0*cm;
  G4double worldLength = 250.0*cm;
  G4double eDetectorThickness = 25.0*cm;
  G4double siliconThickness = 0.2*cm;
  G4double siliconRadius = 20.0*cm;
  G4double siliconZ = -320.0*cm;
  G4double siliconGaps = 80.0*cm;
  G4double ringThickness = 2.0*cm;

  // Definitions of Solids, Logical Volumes, Physical Volumes

  // WORLD: Solid (cube)
  G4GeometryManager::GetInstance()->SetWorldMaximumExtent( worldLength );
  G4Box* worldS = new G4Box(
                 "World",         // its name
                 worldLength,
                 worldLength,
                 worldLength );   // its size (in half-lengths)

  // WORLD: Logical volume (how to treat it)
  G4LogicalVolume* worldLV = new G4LogicalVolume(
                 worldS,          // its solid
                 vacuum,          // its material
                 "World" );       // its name

  // WORLD: Physical volume (where is it)
  // Must place the World Physical volume unrotated at (0,0,0).
  G4VPhysicalVolume* worldPV = new G4PVPlacement(
                 0,               // no rotation
                 G4ThreeVector(0.0, 0.0, 0.0), // in the centre
                 worldLV,         // its logical volume
                 "World",         // its name
                 0,               // its mother volume
                 false,           // no boolean operations
                 0,               // copy number
                 true );          // checking overlaps




  // Silicon detectors (3)
  for (unsigned int layerIndex = 1; layerIndex <= nSLayers; ++ layerIndex)
  {
    std::string mdetectorName = "sDetector" + std::to_string( layerIndex );

    // Silicon Detector: Solid (Cube)
    G4Tubs* sTrackerS = new G4Tubs(
                  mdetectorName,       //its name
                  0,                   // inner radius
                  siliconRadius,      // Outer radius
                  siliconThickness, // how long it extends
                  0.0*deg,
                  360*deg );

    G4LogicalVolume* sTrackerLV = new G4LogicalVolume(

                  sTrackerS,          // its solid
                  silicon,            // its material
                  mdetectorName );     // its name

      siliconZ += siliconGaps;
      G4ThreeVector siliconPosition( 0, 0, siliconZ );
      siliconZ += siliconThickness;

    G4VPhysicalVolume* sTrackerPV = new G4PVPlacement(
                  0,                  // no rotation
                  siliconPosition,    // before EM calorimeter
                  sTrackerLV,         // logical volume
                  mdetectorName,        // name
                  worldLV,                  // mother volume
                  false,              // no boolean operations
                  0,                  // copy number
                  true );             // check overlaps

    // ABSORBER: Quit if there's an overlap
    if ( sTrackerPV->CheckOverlaps() ) std::cerr << "WARNING: your simulated objects overlap" << std::endl;


    }
/*
  // Between silicon and liquid argon make protective layer
  // RING: Solid (Cube)
  G4Tubs* sPlugS = new G4Tubs(
                "Ring",       //its name
                siliconRadius-30.0*cm,                   // inner radius
                siliconRadius,      // Outer radius
                ringThickness, // how long it extends
                0.0*deg,
                360*deg );

  G4LogicalVolume* sPlugLV = new G4LogicalVolume(

                sPlugS,          // its solid
                lead,            // its material
                "Ring" );     // its name

  G4VPhysicalVolume* sPlugPV = new G4PVPlacement(
                0,                  // no rotation
                G4ThreeVector(0.0, 0.0, -75.0*cm),    // before EM calorimeter after silicon
                sPlugLV,         // logical volume
                "Ring",        // name
                worldLV,                  // mother volume
                false,              // no boolean operations
                0,                  // copy number
                true );             // check overlaps
  // RING: Quit if there's an overlap
  if ( sPlugPV->CheckOverlaps() ) std::cerr << "WARNING: your simulated objects overlap" << std::endl;
*/
  // Make multiple layers
  G4double zPosition = 0.0;
  for ( unsigned int layerIndex = 1; layerIndex <= nLayers; ++layerIndex )
  {
    // First layer, make EM calorimeter
    if (layerIndex ==1){
      // Keep CsI near middle
      zPosition = 0.0;
      std::string detectorName = "Detector" + std::to_string( layerIndex );
      // ELECTROMAG DETECTOR: Solid (tube)
      G4Tubs* eDetectorS = new G4Tubs(
                    detectorName,        // its name
                    0.0,                // inner radius 0, so its a solid cylinder
                    absorberRadius,     // outer radius, using same radius as the absorber so no need apply memory for it
                    eDetectorThickness, // how much material in the beam path
                    0.0*deg,            // starting angle
                    360.0*deg );        // ending angle (full circle)

      // ELECTROMAG DETECTOR: Logical volume (how to treat it)
      G4LogicalVolume* eDetectorLV = new G4LogicalVolume(
                    eDetectorS,         // its solid
                    liquidArgon,        // its material
                    detectorName,      // its name
                    0, 0, 0 );          // Modifiers we may want to use?

      // ELECTROMAG DETECTOR: Physical volume (where is it)
      G4VPhysicalVolume* eDetectorPV = new G4PVPlacement(
                    0,                                             // no rotation
                    G4ThreeVector(0.0, 0.0, 40.0*cm),                  // where is it, in front of hadronic calorimeter
                    eDetectorLV,        // its logical volume
                    detectorName,      // its name
                    worldLV,            // its mother volume
                    false,              // no boolean operations
                    0,                  // copy number
                    true );             // checking overlaps

      // ABSORBER: Quit if there's an overlap
      if ( eDetectorPV->CheckOverlaps() ) std::cerr << "WARNING: your simulated objects overlap" << std::endl;
      // Move hadronic calorimeter back
      zPosition += eDetectorThickness+40.0*cm;
    }
    // Hadronic calorimeter
    else{
                    // ABSORBER: Layer properties
                    std::string absorberName = "Absorber" + std::to_string( layerIndex );
                    zPosition += absorberThickness;
                    G4ThreeVector absorberPosition( 0, 0, zPosition );
                    zPosition += absorberThickness;

                    // ABSORBER: Solid (tube)
                    G4Tubs* absorberS = new G4Tubs(
                                   absorberName,      // its name
                                   0.0,               // inner radius 0, so it's a solid cylinder (not a hollow tube)
                                   absorberRadius,    // outer radius
                                   absorberThickness, // how much material in the beam path (half length)
                                   0.0*deg,           // starting angle
                                   360.0*deg );       // ending angle (i.e. it's a full circle)

                    // ABSORBER: Logical volume (how to treat it)
                    G4LogicalVolume* absorberLV = new G4LogicalVolume(
                                   absorberS,         // its solid
                                   lead,              // its material
                                   absorberName,      // its name
                                   0, 0, 0 );         // Modifiers we don't use

                    // ABSORBER: Physical volume (where is it)
                    G4VPhysicalVolume* absorberPV = new G4PVPlacement(
                                   0,                 // no rotation
                                   absorberPosition,  // where is it
                                   absorberLV,        // its logical volume
                                   absorberName,      // its name
                                   worldLV,           // its mother volume
                                   false,             // no boolean operations
                                   0,                 // copy number
                                   true );            // checking overlaps

                    // ABSORBER: Quit if there's an overlap
                    if ( absorberPV->CheckOverlaps() ) std::cerr << "WARNING: your simulated objects overlap" << std::endl;

                    // DETECTOR: Layer properties
                    std::string detectorName = "Detector" + std::to_string( layerIndex );
                    zPosition += detectorThickness;
                    G4ThreeVector detectorPosition( 0, 0, zPosition );
                    zPosition += detectorThickness;

                    // DETECTOR: Solid (tube)
                    G4Tubs* detectorS = new G4Tubs(
                                   detectorName,      // its name
                                   0.0,               // inner radius 0, so it's a solid cylinder (not a hollow tube)
                                   detectorRadius,    // outer radius
                                   detectorThickness, // how much material in the beam path (half length)
                                   0.0*deg,           // starting angle
                                   360.0*deg );       // ending angle (i.e. it's a full circle)

                    // DETECTOR: Logical volume (how to treat it)
                    G4LogicalVolume* detectorLV = new G4LogicalVolume(
                                   detectorS,         // its solid
                                   liquidArgon,       // its material
                                   detectorName,      // its name
                                   0, 0, 0 );         // Modifiers we don't use

                    // DETECTOR: Physical volume (where is it)
                    G4VPhysicalVolume* detectorPV = new G4PVPlacement(
                                   0,                 // no rotation
                                   detectorPosition,  // where is it
                                   detectorLV,        // its logical volume
                                   detectorName,      // its name
                                   worldLV,           // its mother volume
                                   false,             // no boolean operations
                                   0,                 // copy number
                                   true );            // checking overlaps

                    // DETECTOR: Warn if there's an overlap
                    if ( detectorPV->CheckOverlaps() ) std::cerr << "WARNING: your simulated objects overlap" << std::endl;
        }
  }

  // Always return the physical world
  return worldPV;
}

// Set up the magnetic field
void DetectorConstruction::ConstructSDandField()
{
  // Create global magnetic field messenger.
  // Uniform magnetic field is then created automatically if
  // the field value is not zero.
  G4ThreeVector fieldValue = G4ThreeVector();
  m_magneticFieldMessenger = new G4GlobalMagFieldMessenger( fieldValue );

  // Register the field messenger for deleting
  G4AutoDelete::Register( m_magneticFieldMessenger );

  // Make "sensitive detectors" for the liquid argon layers
  for ( unsigned int layerIndex = 1; layerIndex <= nLayers; ++layerIndex )
  {
    std::string detectorName = "Detector" + std::to_string( layerIndex );

    auto argonDetector = new EnergyCounter( detectorName, layerIndex );
    G4SDManager::GetSDMpointer()->AddNewDetector( argonDetector );
    this->SetSensitiveDetector( detectorName, argonDetector );
  }

  // Make sensitive detectors for silicon Tracking
  for ( unsigned int layerIndex = 1; layerIndex <= nSLayers; ++ layerIndex)
  {
    std::string mdetectorName = "sDetector"+ std::to_string( layerIndex );

    auto tracker1 = new PositionFinder( mdetectorName, layerIndex );
    G4SDManager::GetSDMpointer()->AddNewDetector( tracker1 );
    this->SetSensitiveDetector( mdetectorName, tracker1 );

  }
  // Make homogenous calorimeter detector
  //std::string emDetectorName = "eDetector";
  // Label it as "6", as our hadronic calorimeter spans 1-5
  //auto emDetector = new EnergyCounter( emDetectorName, 6);
  //G4SDManager::GetSDMpointer()->AddNewDetector( emDetector);
  //this->SetSensitiveDetector(emDetectorName, emDetector);

}
