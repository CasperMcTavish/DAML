#include "PositionFinder.h"

#include "g4csv.hh"
#include "G4RunManager.hh"

PositionFinder::PositionFinder( const G4String& name, const G4int id ) : G4VSensitiveDetector( name )
{
  // Set which ntuple to use
  m_ID = id;
}

PositionFinder::~PositionFinder()
{
}

// At start of the event, zero the energy counter
void PositionFinder::Initialize( G4HCofThisEvent* )
{
  m_totalEnergy = 0.0;
}

// Analyse anything that hit the detector
G4bool PositionFinder::ProcessHits( G4Step* step, G4TouchableHistory* )
{
  // Tracking detectors only sense charged particles
  if ( step->GetTrack()->GetParticleDefinition()->GetPDGCharge() != 0.0 )
  {
    // Get the analysis manager
    auto analysisManager = G4AnalysisManager::Instance();

    // Fill ntuple with my ID number
    G4String pname = step->GetTrack()->GetParticleDefinition()->GetParticleName();
    /*std::cout << pname << std::endl;
    std::cout << m_ID << std::endl;
    std::cout << step->GetTrack()->GetPosition().x() << std::endl;
    std::cout << step->GetTrack()->GetPosition().y() << std::endl;
    std::cout << step->GetTrack()->GetPosition().z() << std::endl;*/
    analysisManager->FillNtupleIColumn( m_ID, 0, G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID() ); // Column 0 - event number
    analysisManager->FillNtupleDColumn( m_ID, 1, step->GetTrack()->GetPosition().x());                          // Column 1 - x coordinate of hit
    analysisManager->FillNtupleDColumn( m_ID, 2, step->GetTrack()->GetPosition().y());                        // Column 2 - y coordinate of hit
    analysisManager->FillNtupleDColumn( m_ID, 3, step->GetTrack()->GetPosition().z());                        // Column 3 - z coordinate of hit
    analysisManager->FillNtupleSColumn( m_ID, 4, pname);
    analysisManager->FillNtupleDColumn( m_ID, 5, step->GetTotalEnergyDeposit());
    analysisManager->AddNtupleRow( m_ID ); // Row complete
  }

  return true;
}

void PositionFinder::EndOfEvent( G4HCofThisEvent* )
{
}
